FARMERS’ SMILE V1.0 — DATASET
================================

PURPOSE AND SCOPE
Historical weather and crop-screen inputs used by the Farmers’ Smile mobile
web prototype. Supported choices in the app: Chiang Mai, Songkhla, and Surat
Thani provinces. Dates: 1996-01-01 through 2025-12-31 inclusive. Each province
uses one nearby coarse NASA POWER grid-point weather reference, not a
province-wide average or a measurement from every farm.

FOLDER STRUCTURE
source/weather/<area>/nasa-power-1996-2025.json
  Original NASA POWER daily JSON response with parameters T2M, T2M_MAX,
  PRECTOTCORR. The exact request URL, retrieval date and SHA-256 are inside
  the corresponding processed/<area>/validation.json under dataChecks.
source/map/thailand-districts.geojson
  Original bundled/simplified administrative geometry used to derive the map.
source/map/boundary-source.json
  Boundary origin and license metadata.
processed/<area>/daily-weather.csv
  Derived table with 10,958 records per reference area. Columns:
  date (YYYY-MM-DD); temperature_mean_c (degrees C); temperature_max_c
  (degrees C); rain_mm (daily corrected precipitation, millimetres).
processed/<area>/monthly-weather.csv
  Derived table with 360 months per reference area. Columns:
  year, month, days, temp (mean degrees C), rain (sum mm), dryDays (days with
  rainfall below 1 mm), hotDays (days with daily max at least 35 C),
  longestDry (longest run of days with rainfall below 1 mm).
processed/<area>/crops.json
  Crop screening assumptions: crop id, English/Thai names, example window
  length, broad water and temperature ranges, and plain-language notes.
processed/<area>/model.json
  Prepared monthly summaries, crop windows, historical-neighbor comparison
  inputs, and model metadata. This includes a historical comparison component
  and older forecast-evaluation metadata. The app does not present its crop
  ratings as a validated next-year forecast.
processed/<area>/historical-crop-windows.json
  Historical crop-weather comparison windows used by the prepared model.
processed/<area>/validation.json
  Source checks, coverage, and documented evaluation records.
processed/map/
  Grouped pilot province boundaries and country outline derived for the app.
processed/runtime-tests.json
  The local project's recorded automated runtime checks.
PACKAGE_CHECKS.json
  Checks performed while assembling this exact dataset package.
SOURCE_CREDITS.txt
  Data attribution, links, and license information.

AREA NAME MAPPING
  chiang-mai                    -> Chiang Mai province
  songkhla-reference-bang-klam  -> Songkhla province
  surat-thani-reference-phunphin -> Surat Thani province
Bang Klam and Phunphin are internal historical reference identifiers inherited
from an earlier prototype. They are NOT extra selectable areas. Weather grid
coordinates for Songkhla and Surat Thani differ from the reference marker
coordinates; use dataChecks.weatherGridLatitude/Longitude and sourceURL for the
actual weather point.

HOW TO USE
The code ZIP and GitHub repository contain the runnable app plus
scripts/prepare_data.py, scripts/prepare_boundaries.py, scripts/package.py,
and scripts/test.cjs. The browser loads generated JavaScript bundles in dist/;
it does not fetch these CSV or JSON files at runtime. To reproduce preparation,
place the dataset files at their original dist/data/ paths described in the
repository README, or use the repository's included copies. These structured
folders are for separate review and upload, not a drop-in replacement for
that dist/data/ layout.

LIMITS
Crop ratings compare broad crop requirements with similar historical seasons
and fixed screening rules. They do not predict next-year weather, yield,
profit, farm soil, or actual water access. There is no field-outcome validation.
The app's Thai text and crop explanations are interface content, not learned
from these weather records. The soil data discussed as a future reference is
not included or used by V1.0.

CHECKS
All three original raw weather SHA-256 hashes match validation.json.
Each area has 10,958 daily and 360 monthly rows. The Southern validation.json
files contain older modelJSONBytes figures; PACKAGE_CHECKS.json records the
actual byte sizes for the packaged model files. The source ZIP's automated
app tests passed all 72 province/month/water combinations on 2026-10-04.
